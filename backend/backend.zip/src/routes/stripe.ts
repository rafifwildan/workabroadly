// import { Router } from "express"
// import { createCheckout, getProducts } from "../controllers/stripeController"

// const router = Router()

// // POST /api/stripe/checkout - Create checkout session
// router.post("/checkout", createCheckout)

// // GET /api/stripe/products - Get available products
// router.get("/products", getProducts)

// export default router
