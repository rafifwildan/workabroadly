import { Request, Response } from "express";
import User from "../models/User";

// PUT /api/user/profile - Update user profile
export const updateProfile = async (req: Request, res: Response) => {
  try {
    const userId = req.user?.userId;
    const { name, targetCountry, learningGoals } = req.body;

    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    // Validate input
    if (!name || name.trim().length === 0) {
      return res.status(400).json({ message: "Name is required" });
    }

    // Update user profile
    const updatedUser = await User.findByIdAndUpdate(
      userId,
      {
        name: name.trim(),
        targetCountry: targetCountry || undefined,
        learningGoals: learningGoals || undefined,
      },
      { new: true, runValidators: true }
    ).select("-password");

    if (!updatedUser) {
      return res.status(404).json({ message: "User not found" });
    }

    res.status(200).json({
      message: "Profile updated successfully",
      user: updatedUser,
    });
  } catch (error: any) {
    console.error("Update profile error:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// POST /api/user/onboarding - Save onboarding data
export const saveOnboarding = async (req: Request, res: Response) => {
  try {
    const userId = req.user?.userId;
    const { targetCountry, learningGoals } = req.body;

    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    // Validate input
    if (!targetCountry) {
      return res.status(400).json({ message: "Target country is required" });
    }

    // Update user with onboarding data
    const updatedUser = await User.findByIdAndUpdate(
      userId,
      {
        targetCountry,
        learningGoals: learningGoals || undefined,
        isOnboarded: true,
      },
      { new: true, runValidators: true }
    ).select("-password");

    if (!updatedUser) {
      return res.status(404).json({ message: "User not found" });
    }

    res.status(200).json({
      message: "Onboarding completed successfully",
      user: updatedUser,
    });
  } catch (error: any) {
    console.error("Onboarding error:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// GET /api/user/plan - Get user plan information
export const getPlanInfo = async (req: Request, res: Response) => {
  try {
    const userId = req.user?.userId;

    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const user = await User.findById(userId).select(
      "planTier credits planExpiry"
    );

    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.status(200).json({
      planTier: user.planTier,
      credits: user.credits,
      planExpiry: user.planExpiry,
    });
  } catch (error: any) {
    console.error("Get plan info error:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};

// DELETE /api/user/account - Delete user account
export const deleteAccount = async (req: Request, res: Response) => {
  try {
    const userId = req.user?.userId;

    if (!userId) {
      return res.status(401).json({ message: "Unauthorized" });
    }

    const deletedUser = await User.findByIdAndDelete(userId);

    if (!deletedUser) {
      return res.status(404).json({ message: "User not found" });
    }

    res.status(200).json({
      message: "Account deleted successfully",
    });
  } catch (error: any) {
    console.error("Delete account error:", error);
    res.status(500).json({ message: "Server error", error: error.message });
  }
};