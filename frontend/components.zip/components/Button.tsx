import { Button as ShadcnButton } from "@/components/ui/button"

export { ShadcnButton as Button }
